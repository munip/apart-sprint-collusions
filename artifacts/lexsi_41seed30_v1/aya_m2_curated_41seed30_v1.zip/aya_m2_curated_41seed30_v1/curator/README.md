---
tags:
- curatorkit
configs:
- config_name: sft_alpaca
  default: true
  description: curatorkit sft_alpaca export, sha256 578dc32083ca89e711a6b314731a809fdd723a27f21c648fc3654fb6b5a03fc6
  data_files:
  - split: train
    path: sft_alpaca.jsonl
---

# Dataset Card: curatorkit_run

## Summary

- **Run timestamp**: 2026-11-16T09:00:46.927833Z
- **Wall clock time**: 0.0s
- **Pipeline config hash**: `f51426d40e997209`

## Source Documents

  - Unknown

## Pipeline Stages

| Step | Input | Passed | Recovered | Rejected | Forward |
|------|-------|--------|-----------|----------|---------|
| JSONLReader | 78 | 78 | — | 0 | 78 |
| SchemaGate | 78 | 78 | 0 | 0 | 78 |
| AlpacaExporter | — | 78 | — | — | 78 |

## Gate Pass Rates and Rejection Breakdown

- **JSONLReader**: 78/0 passed (N/A), 0 rejected
- **SchemaGate**: 78/78 passed (100.0%), 0 rejected


**Rejection reasons:**
  - None

## Deduplication

  - No deduplication step recorded

## Known Limitations

- No MinHash deduplication applied.
- Table extraction requires `extract_tables: true` on the PDF reader and MinerU with GPU support. Disabled by default.
- Token counting uses a whitespace tokenizer by default. For exact LLM context window
  enforcement, enable `use_tiktoken: true` in the SchemaGate config.
- Both within-run (MinHash/Diversity) and cross-run (EmbeddingDeduplicator) deduplication
  are available. Cross-run dedup persists an embedding index across runs; use
  `embedding_reset_index: true` to start fresh.

## Reproduction

```bash
pip install curatorkit
curatorkit run pipeline.yaml --output-dir ./out/
```

## Tool Versions

- **curatorkit**: 0.1.29
- **python**: 3.13.16

## Configs

Load one with `datasets.load_dataset("<this folder or Hub repo>", "<config>")`.

| Config | Splits (rows) | Columns |
|--------|---------------|---------|
| `sft_alpaca` | train (78) | `instruction`: string<br>`input`: string (empty when there is no input)<br>`output`: string |
